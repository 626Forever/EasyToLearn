package app.main.ui.memo;

public class MemoCallCode {
	public final static int BROWSE_CALL_NEW = 0;
	public final static int MAIN_CALL_NEW = 3;
}
