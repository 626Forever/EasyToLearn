package app.main.ui.wrong;

public class WrongCallCode {
	public final static int BROWSE_CALL_NEW = 0;
	public final static int LIST_CALL_NEW = 1;
	public final static int LIST_CALL_BROWSE = 2;
	public final static int MAIN_CALL_NEW = 3;
}
